# VegPurchase — Deployment Guide

## 📁 Files in this package
```
vegpurchase-deploy/
├── index.html       ← Main app (all-in-one)
├── manifest.json    ← PWA manifest
├── sw.js            ← Service worker (offline support)
├── _redirects       ← Netlify routing config
└── icons/           ← App icons (all sizes)
    ├── icon-72.png
    ├── icon-96.png
    ├── icon-128.png
    ├── icon-144.png
    ├── icon-152.png
    ├── icon-192.png
    ├── icon-384.png
    └── icon-512.png
```

---

## 🚀 STEP 1 — Deploy to Netlify (Free, 5 minutes)

1. Go to **https://netlify.com** → Sign up free
2. Click **"Add new site"** → **"Deploy manually"**
3. **Drag and drop** the entire `vegpurchase-deploy` folder
4. Wait 30 seconds → you get a live URL like:
   `https://vegpurchase-abc123.netlify.app`
5. Optional: Go to **Site settings → Domain** → change to custom name like `vegpurchase.netlify.app`

---

## 📱 STEP 2 — Convert to Android APK (PWABuilder)

1. Go to **https://www.pwabuilder.com**
2. Paste your Netlify URL → Click **"Start"**
3. Click **"Package for Store"**
4. Select **Android**
5. Fill in:
   - App name: `VegPurchase`
   - Package ID: `com.vegpurchase.app`
   - Version: `1.0.0`
6. Click **"Generate Package"** → Download the `.aab` file

---

## 🏪 STEP 3 — Submit to Play Store

1. Go to **https://play.google.com/console**
2. Click **"Create app"**
3. Fill details:
   - **App name**: VegPurchase
   - **Default language**: English
   - **App or game**: App
   - **Free or paid**: Free
4. Go to **"Production"** → **"Create new release"**
5. Upload the `.aab` file from Step 2
6. Fill in:
   - Release name: `1.0.0`
   - Release notes: `Daily vegetable purchase manager for all branches`
7. Add screenshots (take screenshots from your phone)
8. Submit for review → **3-7 days** for approval

---

## 🔑 App Login Details

| Role  | Login |
|-------|-------|
| Admin | PIN: `0000` |
| Hasthinapuram | PIN: `1111` |
| Tambaram | PIN: `2222` |
| Pammal | PIN: `3333` |
| Pazhavanthangal | PIN: `4444` |
| Keelkatalai | PIN: `5555` |
| Perumbakkam | PIN: `6666` |
| Taramani | PIN: `7777` |
| Ekkattuthangal | PIN: `8888` |
| Mugalivakkam | PIN: `9999` |
| 3 Bar | PIN: `1234` |
| Central Kitchen | PIN: `5678` |

---

## 📲 Install as App Without Play Store (Instant!)

Share the Netlify link with branch staff. On Android:
1. Open link in **Chrome**
2. Tap **menu (⋮)** → **"Add to Home screen"**
3. App icon appears on home screen — works like a native app!

---

Built with ❤️ — VegPurchase
